#ifndef GWIDGET_GLOBAL_H
#define GWIDGET_GLOBAL_H

#include <gglobal/export_define.h>
#include <QString>

extern const QString cComboListNameKey;
extern const QString cComboListTextKey;
extern const QString cComboListIconKey;
extern const QString cComboListUserDataKey;


#endif // GWIDGET_GLOBAL_H
