#ifndef GWIDGET_GLOBAL_H
#define GWIDGET_GLOBAL_H

#include <gglobal/export_define.h>

#endif // GWIDGET_GLOBAL_H
#ifndef RUNINFOWIDGET_H
#define RUNINFOWIDGET_H

#include "gwidget_global.h"
#include <gglobal/dpoint.h>
#include <QTextEdit>

QT_BEGIN_NAMESPACE
class QKeyEvent;
class QCloseEvent;
QT_END_NAMESPACE

class G_WIDGET_EXPORT RunInfoWidget : public QTextEdit
{
    Q_OBJECT
    G_DECLARE_DP(RunInfoWidget)
public:
    explicit RunInfoWidget(QWidget *iParent = nullptr);

    void installMessageHandler();
    void closeMessageHandler();

protected:
    void keyPressEvent(QKeyEvent *iEvent);
    void closeEvent(QCloseEvent *iEvent);
};

#endif // RUNINFOWIDGET_H
